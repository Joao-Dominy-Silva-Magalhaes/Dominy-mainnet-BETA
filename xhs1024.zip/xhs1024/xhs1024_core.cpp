#include "xhs1024_core.hpp"
#include "xhs1024_constants.hpp"

namespace xhs1024 {

void compress(u128 state[8], const uint8_t block[BLOCK_BYTES]) {
    u128 v[8];
    for (int i = 0; i < 8; ++i)
        v[i] = state[i];

    u128 m[16];
    for (int i = 0; i < 16; ++i)
        m[i] = load_u128(block + i * 16);

    for (size_t r = 0; r < ROUNDS; ++r) {
        size_t i = r & 7;
        size_t j = (i + 1) & 7;

        v[i] = v[i] + v[j];
        v[j] = rotl(v[j] ^ v[i], (r % 127) + 1);
        v[i] = v[i] + K[r & 255];
    }

    for (int i = 0; i < 8; ++i)
        state[i] = state[i] ^ v[i];
}

} // namespace xhs1024