#include "xhs1024_api.hpp"
#include "xhs1024_core.hpp"
#include "xhs1024_constants.hpp"
#include <cstring>

namespace xhs1024 {

std::vector<uint8_t> hash(const uint8_t* data, size_t len) {
    u128 state[8];
    for (int i = 0; i < 8; ++i)
        state[i] = IV[i];

    uint8_t block[BLOCK_BYTES] = {0};

    size_t offset = 0;
    while (offset + BLOCK_BYTES <= len) {
        compress(state, data + offset);
        offset += BLOCK_BYTES;
    }

    std::memcpy(block, data + offset, len - offset);
    block[len - offset] = 0x80;

    compress(state, block);

    std::vector<uint8_t> out(DIGEST_BYTES);
    for (int i = 0; i < 8; ++i)
        store_u128(out.data() + i * 16, state[i]);

    return out;
}

} // namespace xhs1024