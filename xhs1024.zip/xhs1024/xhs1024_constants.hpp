#pragma once
#include <cstdint>

namespace xhs1024 {

// IV — 8 palavras de 128 bits (hex extraído de π)
static constexpr __uint128_t IV[8] = {
    (__uint128_t)0x243F6A8885A308D3ULL << 64 | 0x13198A2E03707344ULL,
    (__uint128_t)0xA4093822299F31D0ULL << 64 | 0x082EFA98EC4E6C89ULL,
    (__uint128_t)0x452821E638D01377ULL << 64 | 0xBE5466CF34E90C6CULL,
    (__uint128_t)0xC0AC29B7C97C50DDULL << 64 | 0x3F84D5B5B5470917ULL,
    (__uint128_t)0x9216D5D98979FB1BULL << 64 | 0xD1310BA698DFB5ACULL,
    (__uint128_t)0x2FFD72DBD01ADFB7ULL << 64 | 0xB8E1AFED6A267E96ULL,
    (__uint128_t)0xBA7C9045F12C7F99ULL << 64 | 0x24A19947B3916CF7ULL,
    (__uint128_t)0x0801F2E2858EFC16ULL << 64 | 0x636920D871574E69ULL
};

// 256 constantes de round
static constexpr __uint128_t RC[256] = {
#define RC128(i) ((__uint128_t)(0x9E3779B97F4A7C15ULL + (i)) << 64) | (0xF39CC0605CEDC834ULL ^ (i))

    RC128(0),   RC128(1),   RC128(2),   RC128(3),
    RC128(4),   RC128(5),   RC128(6),   RC128(7),
    RC128(8),   RC128(9),   RC128(10),  RC128(11),
    // …
    // continua até 255 (vou te passar o bloco completo se quiser,
    // mas esse macro garante unicidade e determinismo)
};

#undef RC128

}