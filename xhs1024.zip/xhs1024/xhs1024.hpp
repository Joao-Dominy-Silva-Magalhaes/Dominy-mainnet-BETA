#pragma once
#include <array>
#include <cstdint>
#include <vector>
#include <string>


namespace xhs1024 {


using word128 = std::array<uint64_t, 2>; // 128 bits
using state1024 = std::array<word128, 8>; // 8 palavras = 1024 bits


state1024 hash(const std::vector<uint8_t>& data);
std::string hash_hex(const std::vector<uint8_t>& data);


}