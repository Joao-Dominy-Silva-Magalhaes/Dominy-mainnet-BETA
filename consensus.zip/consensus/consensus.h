#ifndef CONSENSUS_H
#define CONSENSUS_H

#include <string>
#include <map>
#include <mutex>
#include <vector>
#include "transaction.h"
#include "block_header.h"

class Consensus {
private:
    std::map<std::string, double> balances;
    mutable std::mutex consensus_mutex;
    double reward_pool;

public:
    Consensus();
    
    // Funções de Validação e Aplicação
    bool validate_transaction_oqs(const Transaction& tx);
    bool apply_block(const Block& block, const std::string& miner_address);
    double get_current_reward(uint64_t height);
    
    // Getters e Utilidades
    double get_balance(const std::string& address) const;
    
    // Inicialização e Persistência
    void force_genesis_supply(const std::string& address, double amount);
    void save_state(const std::string& filename);
    void load_state(const std::string& filename);
};

#endif