#include "consensus.h"
#include <oqs/oqs.h>
#include <iostream>
#include <fstream>

Consensus::Consensus() : reward_pool(0.0) {}

void Consensus::force_genesis_supply(const std::string& address, double amount) {
    std::lock_guard<std::mutex> lock(consensus_mutex);
    balances[address] = amount;
}

bool Consensus::validate_transaction_oqs(const Transaction& tx) {
    // CORREÇÃO: Usando a macro padrão ou o nome do algoritmo
    // Se OQS_SIG_alg_dilithium_2 não funcionar, a liboqs aceita a string abaixo:
    OQS_SIG *sig = OQS_SIG_new("Dilithium2"); 
    
    if (!sig) {
        std::cerr << "[ERRO OQS] Falha ao carregar Dilithium2" << std::endl;
        return false;
    }

    std::vector<uint8_t> msg = tx.serialize_for_hash();
    
    // Verifica a assinatura OQS contra a chave pública (sender)
    if (OQS_SIG_verify(sig, msg.data(), msg.size(), tx.signature.data(), tx.signature.size(), (uint8_t*)tx.sender.data()) != OQS_SUCCESS) {
        OQS_SIG_free(sig);
        return false;
    }

    OQS_SIG_free(sig);
    return true;
}

bool Consensus::apply_block(const Block& block, const std::string& miner_address) {
    std::lock_guard<std::mutex> lock(consensus_mutex);
    double total_fees = 0.0;
    
    for (const auto& tx : block.transactions) {
        if (balances[tx.sender] < (tx.amount + tx.fee)) return false;
        if (!validate_transaction_oqs(tx)) return false;

        balances[tx.sender] -= (tx.amount + tx.fee);
        balances[tx.receiver] += tx.amount;
        total_fees += tx.fee;
    }

    double base_reward = get_current_reward(block.header.height);
    balances[miner_address] += (base_reward + reward_pool + total_fees);
    reward_pool = 0.0;
    return true;
}

double Consensus::get_current_reward(uint64_t height) {
    uint64_t ano = height / 131400; 
    if (ano < 2) return 64.0;
    if (ano < 4) return 32.0;
    if (ano < 6) return 16.0;
    if (ano < 8) return 8.0;
    return 2.0;
}

double Consensus::get_balance(const std::string& address) const {
    std::lock_guard<std::mutex> lock(consensus_mutex);
    auto it = balances.find(address);
    return (it != balances.end()) ? it->second : 0.0;
}

void Consensus::save_state(const std::string& filename) {
    std::ofstream f(filename, std::ios::binary);
    if (!f.is_open()) return;
    size_t s = balances.size();
    f.write((char*)&s, sizeof(s));
    for (auto const& [addr, bal] : balances) {
        size_t al = addr.size();
        f.write((char*)&al, sizeof(al));
        f.write(addr.c_str(), al);
        f.write((char*)&bal, sizeof(bal));
    }
}

void Consensus::load_state(const std::string& filename) {
    std::ifstream f(filename, std::ios::binary);
    if (!f.is_open()) return;
    size_t s;
    f.read((char*)&s, sizeof(s));
    for (size_t i=0; i<s; ++i) {
        size_t al; f.read((char*)&al, sizeof(al));
        std::string addr(al, ' ');
        f.read(&addr[0], al);
        double bal; f.read((char*)&bal, sizeof(bal));
        balances[addr] = bal;
    }
}