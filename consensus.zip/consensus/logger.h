#pragma once
#include <string>
#include <iostream>
#include <mutex>

class Logger {
public:
    enum LogLevel { LOG_INFO, LOG_WARN, LOG_ERROR };

    static void init() {}

    static void info(const std::string& msg) { write_log(LOG_INFO, msg); }
    static void warn(const std::string& msg) { write_log(LOG_WARN, msg); }
    static void error(const std::string& msg) { write_log(LOG_ERROR, msg); }

private:
    static std::mutex log_mutex;
    static void write_log(LogLevel level, const std::string& msg) {
        std::lock_guard<std::mutex> lock(log_mutex);
        switch(level) {
            case LOG_INFO:  std::cout << "[INFO] "; break;
            case LOG_WARN:  std::cout << "[WARN] "; break;
            case LOG_ERROR: std::cout << "[ERROR] "; break;
        }
        std::cout << msg << std::endl;
    }
};