#include "block_io.h"
#include <fstream>
#include <filesystem>
#include <iostream>

namespace fs = std::filesystem;

// Implementação do salvamento de bloco no disco (.dom)
bool BlockIO::save_block(const Block& block) {
    // Garante que a pasta blocks existe
    if (!fs::exists("blocks")) fs::create_directory("blocks");

    std::string filename = "blocks/block_" + std::to_string(block.header.height) + ".dom";
    std::ofstream f(filename, std::ios::binary);
    
    if (!f.is_open()) return false;

    // 1. Salva o Header (Tamanho fixo)
    f.write((char*)&block.header, sizeof(block.header));
    
    // 2. Salva a quantidade de transações
    size_t tx_count = block.transactions.size();
    f.write((char*)&tx_count, sizeof(tx_count));

    // 3. Salva cada transação serializada com seu tamanho
    for (const auto& tx : block.transactions) {
        std::vector<uint8_t> serialized = tx.serialize_full();
        uint32_t data_size = static_cast<uint32_t>(serialized.size());
        f.write((char*)&data_size, sizeof(data_size));
        f.write((char*)serialized.data(), data_size);
    }

    f.close();
    return true;
}

// ESTA É A FUNÇÃO QUE ESTAVA FALTANDO/ERRADA NO LINKER
bool BlockIO::load_block(uint64_t height, Block& block) {
    std::string filename = "blocks/block_" + std::to_string(height) + ".dom";
    if (!fs::exists(filename)) return false;

    std::ifstream f(filename, std::ios::binary);
    if (!f.is_open()) return false;

    // 1. Lê o Header
    f.read((char*)&block.header, sizeof(block.header));

    // 2. Lê quantidade de transações
    size_t tx_count;
    f.read((char*)&tx_count, sizeof(tx_count));

    // 3. Lê cada transação
    block.transactions.clear();
    for (size_t i = 0; i < tx_count; ++i) {
        uint32_t data_size;
        f.read((char*)&data_size, sizeof(data_size));
        
        std::vector<uint8_t> buffer(data_size);
        f.read((char*)buffer.data(), data_size);
        
        block.transactions.push_back(Transaction::deserialize(buffer));
    }

    f.close();
    return true;
}