#include "logger.h"

// Isso resolve o erro "undefined reference to Logger::log_mutex"
std::mutex Logger::log_mutex;