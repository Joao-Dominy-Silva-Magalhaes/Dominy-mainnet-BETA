#ifndef BLOCK_HEADER_H
#define BLOCK_HEADER_H

#include <cstdint>
#include <vector>
#include <string>
#include "transaction.h"

#pragma pack(push, 1)
struct BlockHeader {
    uint32_t version;
    uint64_t height;
    uint64_t timestamp;
    uint32_t difficulty;
    uint64_t nonce;
    uint8_t prev_block_hash[32]; 
    uint8_t block_hash[32];      
    uint8_t merkle_root[32];
};
#pragma pack(pop)

struct Block {
    BlockHeader header;
    std::string hash; 
    std::vector<Transaction> transactions;
};

#endif