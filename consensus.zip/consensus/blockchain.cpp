#include "blockchain.h"
#include "xhs1024.h"
#include "block_io.h"
#include <iostream>
#include <ctime>
#include <cstring>
#include <filesystem>

namespace fs = std::filesystem;

Blockchain::Blockchain(Consensus& c, Mempool& m) 
    : consensus_engine(c), mempool(m), initial_difficulty(4) {}

// Implementação da Árvore de Merkle de 1024 bits para segurança Mainnet
void Blockchain::calculate_merkle_root(const std::vector<Transaction>& txs, uint8_t* output_root) {
    if (txs.empty()) {
        memset(output_root, 0, 32);
        return;
    }

    std::vector<std::vector<uint8_t>> layers;
    for (const auto& tx : txs) {
        layers.push_back(std::vector<uint8_t>(tx.tx_id, tx.tx_id + 32));
    }

    while (layers.size() > 1) {
        if (layers.size() % 2 != 0) layers.push_back(layers.back());
        std::vector<std::vector<uint8_t>> next_layer;

        for (size_t i = 0; i < layers.size(); i += 2) {
            uint8_t combined[64];
            memcpy(combined, layers[i].data(), 32);
            memcpy(combined + 32, layers[i+1].data(), 32);

            uint8_t hash_out[128];
            xhs1024_hash(combined, 64, hash_out);
            next_layer.push_back(std::vector<uint8_t>(hash_out, hash_out + 32));
        }
        layers = next_layer;
    }
    memcpy(output_root, layers[0].data(), 32);
}

// Submissão de blocos minerados (Chamado pelo dominy_node.cpp)
bool Blockchain::submit_mined_block(const std::string& miner_addr, uint32_t nonce, double reward) {
    std::lock_guard<std::mutex> lock(blockchain_mutex);
    
    Block new_block;
    new_block.header.height = get_height() + 1;
    new_block.header.timestamp = static_cast<uint64_t>(std::time(nullptr));
    new_block.header.nonce = nonce;
    new_block.header.difficulty = initial_difficulty;
    
    if (!chain.empty()) {
        memcpy(new_block.header.prev_block_hash, chain.back().header.block_hash, 32);
    }

    // Pega transações da mempool (Regra de 200k txs / 1GB)
    new_block.transactions = mempool.get_pending_transactions(200000);

    // Calcula o Merkle Root real das transações
    calculate_merkle_root(new_block.transactions, new_block.header.merkle_root);

    if (consensus_engine.apply_block(new_block, miner_addr)) {
        if (BlockIO::save_block(new_block)) {
            chain.push_back(new_block);
            mempool.remove_transactions(new_block.transactions);
            return true;
        }
    }
    return false;
}

// Carrega os blocos existentes do disco ao iniciar [cite: 2025-12-31]
void Blockchain::load_from_disk() {
    std::lock_guard<std::mutex> lock(blockchain_mutex);
    uint64_t h = 0;
    while (true) {
        Block b;
        if (BlockIO::load_block(h, b)) {
            chain.push_back(b);
            h++;
        } else {
            break;
        }
    }
    std::cout << "[SISTEMA] Blockchain carregada. Altura atual: " << get_height() << std::endl;
}

// Cria o Bloco Genesis com o supply inicial de 15 milhões [cite: 2025-12-25]
void Blockchain::force_genesis_block(const std::string& address) {
    std::lock_guard<std::mutex> lock(blockchain_mutex);
    if (!chain.empty()) return;

    Block genesis;
    genesis.header.height = 0;
    genesis.header.timestamp = static_cast<uint64_t>(std::time(nullptr));
    genesis.header.difficulty = initial_difficulty;
    memset(genesis.header.prev_block_hash, 0, 32);
    memset(genesis.header.block_hash, 0x11, 32); // Assinatura fixa do genesis

    if (BlockIO::save_block(genesis)) {
        chain.push_back(genesis);
        consensus_engine.force_genesis_supply(address, 15000000.0);
        std::cout << "[IO] Bloco Genesis gerado com sucesso para: " << address << std::endl;
    }
}

// Mantém a blockchain viva criando blocos vazios se não houver mineradores [cite: 2025-12-29]
void Blockchain::generate_empty_block() {
    std::lock_guard<std::mutex> lock(blockchain_mutex);
    Block empty_block;
    empty_block.header.height = get_height() + 1;
    empty_block.header.timestamp = static_cast<uint64_t>(std::time(nullptr));
    memset(empty_block.header.merkle_root, 0, 32);
    
    if (!chain.empty()) {
        memcpy(empty_block.header.prev_block_hash, chain.back().header.block_hash, 32);
    }

    if (BlockIO::save_block(empty_block)) {
        chain.push_back(empty_block);
        std::cout << "[SISTEMA] Bloco Vazio #" << empty_block.header.height << " gerado (Manutenção)." << std::endl;
    }
}

// Getters fundamentais
uint64_t Blockchain::get_height() const {
    return chain.empty() ? 0 : chain.back().header.height;
}

bool Blockchain::has_new_activity() {
    // Verifica se houve novos blocos nos últimos 4 minutos
    if (chain.empty()) return false;
    uint64_t now = static_cast<uint64_t>(std::time(nullptr));
    return (now - chain.back().header.timestamp) < 240; 
}