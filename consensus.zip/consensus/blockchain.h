#ifndef BLOCKCHAIN_H
#define BLOCKCHAIN_H

#include <vector>
#include <string>
#include <mutex>
#include "block_header.h"
#include "consensus.h"
#include "mempool.h"

class Blockchain {
private:
    std::vector<Block> chain;
    Consensus& consensus_engine;
    Mempool& mempool;
    uint32_t initial_difficulty;
    mutable std::mutex blockchain_mutex;

public:
    Blockchain(Consensus& c, Mempool& m);
    
    void calculate_merkle_root(const std::vector<Transaction>& txs, uint8_t* output_root);
    bool submit_mined_block(const std::string& miner_addr, uint32_t nonce, double reward);
    void generate_empty_block();
    
    // Funções que o dominy_node.cpp exige
    void load_from_disk();
    void force_genesis_block(const std::string& address);
    
    uint64_t get_height() const;
    bool has_new_activity();
    uint32_t calculate_next_difficulty() { return initial_difficulty; }
};

#endif