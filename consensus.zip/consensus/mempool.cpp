#include "mempool.h"
#include <algorithm>
#include <cstring>

void Mempool::add_transaction(const Transaction& tx) {
    std::lock_guard<std::mutex> lock(mempool_mutex);
    // Verifica se já existe pelo tx_id (array de 32 bytes)
    for (const auto& existing : pending_transactions) {
        if (memcmp(existing.tx_id, tx.tx_id, 32) == 0) return;
    }
    pending_transactions.push_back(tx);
}

void Mempool::remove_transactions(const std::vector<Transaction>& confirmed_txs) {
    std::lock_guard<std::mutex> lock(mempool_mutex);
    for (const auto& ctx : confirmed_txs) {
        pending_transactions.erase(
            std::remove_if(pending_transactions.begin(), pending_transactions.end(),
                [&](const Transaction& tx) { 
                    return memcmp(tx.tx_id, ctx.tx_id, 32) == 0; 
                }),
            pending_transactions.end());
    }
}

std::vector<Transaction> Mempool::get_pending_transactions(size_t limit) {
    std::lock_guard<std::mutex> lock(mempool_mutex);
    size_t count = std::min(limit, pending_transactions.size());
    return std::vector<Transaction>(pending_transactions.begin(), pending_transactions.begin() + count);
}