#ifndef BLOCK_IO_H
#define BLOCK_IO_H

#include "block_header.h"
#include <string>

class BlockIO {
public:
    static bool save_block(const Block& block);
    static bool load_block(uint64_t height, Block& block); // Esta é a função que o Linker está cobrando
};

#endif