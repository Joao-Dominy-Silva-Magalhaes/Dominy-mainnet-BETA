#ifndef MEMPOOL_H
#define MEMPOOL_H

#include <vector>
#include <mutex>
#include <string>
#include <algorithm>
#include "transaction.h"

class Mempool {
private:
    std::vector<Transaction> pending_transactions;
    mutable std::mutex mempool_mutex;

public:
    Mempool() = default;

    // Funções principais
    void add_transaction(const Transaction& tx);
    std::vector<Transaction> get_pending_transactions(size_t limit);
    void remove_transactions(const std::vector<Transaction>& confirmed_txs);
    
    // Aliases para compatibilidade
    std::vector<Transaction> pegar_transacoes_pendentes(size_t limit) { 
        return get_pending_transactions(limit); 
    }
    void remover_transacoes(const std::vector<Transaction>& txs) { 
        remove_transactions(txs); 
    }

    // Persistência
    void save_to_disk(const std::string& filename);
    void load_from_disk(const std::string& filename);
    
    size_t get_size() const;
    void clear();
};

#endif